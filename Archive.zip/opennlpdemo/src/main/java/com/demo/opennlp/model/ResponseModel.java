package com.demo.opennlp.model;


public class ResponseModel {
	
	String output;
	
	public ResponseModel(String out) {
		this.output = out;
	}

	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}	

}
